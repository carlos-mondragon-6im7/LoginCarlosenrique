package mx.ipn.logincarlosenrique;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class Login extends AppCompatActivity {

    EditText usuario;
    EditText pass;
    Button boton;



    String nombre = "";
    String password = "";
    TextView vista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        boton = (Button) findViewById(R.id.boton);

        usuario = (EditText) findViewById(R.id.usuario);

        pass = (EditText) findViewById(R.id.pass);

        vista = (TextView) findViewById(R.id.vista);


    }

    public void cosita(View v) {
        Intent envia = new Intent(this, Activity2.class);
        Bundle datos = new Bundle();
        datos.putString("nombre", usuario.getText().toString().trim());
        datos.putString("password", pass.getText().toString().trim());

        nombre = usuario.getText().toString();
        password = pass.getText().toString();

        if(nombre.equals("usuarioo")) {
            if(password.equals("123")) {

                envia.putExtras(datos);
                finish();
                startActivity(envia);
            }
        }
        else{
            Intent envia2 = new Intent(this, Login.class);
            Bundle datitos = new Bundle();
            envia2.putExtras(datitos);
            finish();
            startActivity(envia2);
        }
    }
}
